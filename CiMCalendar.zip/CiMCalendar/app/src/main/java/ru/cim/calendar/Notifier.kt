package ru.cim.calendar

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

object Notifier {
    private const val CH = "reminders"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH, "Напоминания", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun alarmIntent(ctx: Context, id: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id, Intent(ctx, AlarmReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun cancelAlarm(ctx: Context, id: Int) {
        ctx.getSystemService(AlarmManager::class.java).cancel(alarmIntent(ctx, id))
    }

    /** Отменяет будильник и убирает показанное уведомление. */
    fun cancel(ctx: Context, id: Int) {
        cancelAlarm(ctx, id)
        ctx.getSystemService(NotificationManager::class.java).cancel(id)
    }

    fun schedule(ctx: Context, x: Item) {
        cancelAlarm(ctx, x.id)
        val t = Store.triggerAt(x) ?: return
        if (t <= System.currentTimeMillis()) return
        val am = ctx.getSystemService(AlarmManager::class.java)
        val p = alarmIntent(ctx, x.id)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
        }
    }

    fun rescheduleAll(ctx: Context, list: List<Item>) {
        for (x in list) schedule(ctx, x)
    }

    fun show(ctx: Context, x: Item) {
        val open = PendingIntent.getActivity(
            ctx, x.id,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        var whenText = D.show(x.date)
        if (x.time.isNotEmpty()) {
            whenText += " " + x.time + (if (x.endTime.isNotEmpty()) "–" + x.endTime else "")
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH)
        else Notification.Builder(ctx).setPriority(Notification.PRIORITY_HIGH)
        b.setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(x.title)
            .setContentText(whenText)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setDefaults(Notification.DEFAULT_ALL)
            .setStyle(
                Notification.BigTextStyle()
                    .bigText(if (x.note.isEmpty()) whenText else whenText + "\n" + x.note)
            )
        ctx.getSystemService(NotificationManager::class.java).notify(x.id, b.build())
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val x = Store.read(ctx).find { it.id == id } ?: return
        if (x.done) return
        Notifier.createChannel(ctx)
        Notifier.show(ctx, x)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Notifier.createChannel(ctx)
        Notifier.rescheduleAll(ctx, Store.read(ctx))
    }
}
