package ru.cim.calendar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.Locale

class Item(
    var id: Int,
    var isTask: Boolean,
    var title: String,
    var note: String = "",
    var date: String = "",      // yyyy-MM-dd, у задачи может быть пустой
    var time: String = "",      // HH:mm или пусто (весь день / без времени)
    var endTime: String = "",   // HH:mm или пусто
    var remind: Int = -1,       // минут до начала, -1 = без напоминания
    var done: Boolean = false
)

val REM_LABELS = arrayOf("Нет", "В момент начала", "За 5 минут", "За 15 минут", "За 30 минут", "За 1 час", "За 1 день")
val REM_MIN = intArrayOf(-1, 0, 5, 15, 30, 60, 1440)

object Store {
    val items = ArrayList<Item>()
    private const val FILE = "data.json"

    /** Читает данные с диска, не трогая общий список (для получателей широковещательных сообщений). */
    @Synchronized
    fun read(ctx: Context): ArrayList<Item> {
        val res = ArrayList<Item>()
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return res
        try {
            val a = JSONArray(f.readText())
            for (k in 0 until a.length()) {
                val o = a.getJSONObject(k)
                res.add(
                    Item(
                        o.getInt("id"), o.getBoolean("task"), o.getString("title"),
                        o.optString("note"), o.optString("date"), o.optString("time"),
                        o.optString("end"), o.optInt("remind", -1), o.optBoolean("done")
                    )
                )
            }
        } catch (e: Exception) {
            f.renameTo(File(ctx.filesDir, "data.bak"))
            res.clear()
        }
        return res
    }

    fun load(ctx: Context) {
        val r = read(ctx)
        items.clear()
        items.addAll(r)
    }

    @Synchronized
    fun save(ctx: Context) {
        val a = JSONArray()
        for (x in items) {
            a.put(
                JSONObject().put("id", x.id).put("task", x.isTask).put("title", x.title)
                    .put("note", x.note).put("date", x.date).put("time", x.time)
                    .put("end", x.endTime).put("remind", x.remind).put("done", x.done)
            )
        }
        val tmp = File(ctx.filesDir, "data.tmp")
        tmp.writeText(a.toString())
        tmp.renameTo(File(ctx.filesDir, FILE))
    }

    fun nextId(): Int = (items.maxOfOrNull { it.id } ?: 0) + 1

    /** Момент срабатывания напоминания; без времени отсчёт идёт от 09:00. */
    fun triggerAt(x: Item): Long? {
        if (x.remind < 0 || x.date.isEmpty() || x.done) return null
        val h = if (x.time.isEmpty()) 9 else x.time.substring(0, 2).toInt()
        val m = if (x.time.isEmpty()) 0 else x.time.substring(3, 5).toInt()
        val c = Calendar.getInstance()
        c.clear()
        c.set(D.y(x.date), D.m(x.date), D.d(x.date), h, m, 0)
        return c.timeInMillis - x.remind * 60000L
    }
}

object D {
    val months = arrayOf(
        "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
        "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
    )
    private val gen = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )
    private val days = arrayOf(
        "воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота"
    )

    /** m — месяц с нуля */
    fun key(y: Int, m: Int, d: Int): String = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)

    fun today(): String {
        val c = Calendar.getInstance()
        return key(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
    }

    fun y(k: String) = k.substring(0, 4).toInt()
    fun m(k: String) = k.substring(5, 7).toInt() - 1
    fun d(k: String) = k.substring(8, 10).toInt()

    fun show(k: String): String = if (k.isEmpty()) "Без даты" else k.substring(8, 10) + "." + k.substring(5, 7) + "." + k.substring(0, 4)

    fun full(k: String): String {
        val c = Calendar.getInstance()
        c.clear()
        c.set(y(k), m(k), d(k))
        return "${d(k)} ${gen[m(k)]}, ${days[c.get(Calendar.DAY_OF_WEEK) - 1]}"
    }
}
