package ru.cim.calendar

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Locale

object C {
    val BG = Color.parseColor("#131313")
    val S1 = Color.parseColor("#1C1C1C")
    val S2 = Color.parseColor("#272727")
    val LN = Color.parseColor("#333333")
    val TX = Color.parseColor("#F2F2EE")
    val MU = Color.parseColor("#9A9A94")
    val AC = Color.parseColor("#AEDB16")
    val DG = Color.parseColor("#FF6A5C")
    val DARK = Color.parseColor("#111111")
}

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var content: FrameLayout
    private lateinit var tabCal: TextView
    private lateinit var tabTasks: TextView
    private var density = 1f
    private var tab = 0
    private var vy = 0
    private var vm = 0
    private var sel = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        density = resources.displayMetrics.density
        Store.load(this)
        Notifier.createChannel(this)
        val t = D.today()
        sel = t
        vy = D.y(t)
        vm = D.m(t)
        buildShell()
        render()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Notifier.rescheduleAll(this, Store.items)
    }

    // ---------- помощники ----------

    private fun dp(v: Int) = (v * density + 0.5f).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun vbox(p: Int = 0) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(p), dp(p), dp(p), dp(p))
    }

    private fun hbox() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun bg(color: Int, r: Int = 12, stroke: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke > 0) setStroke(dp(stroke), sc)
    }

    private fun tv(text: String, size: Float = 16f, color: Int = C.TX, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun btn(text: String, accent: Boolean = false, click: () -> Unit) =
        tv(text, 15f, if (accent) C.DARK else C.TX, accent).apply {
            gravity = Gravity.CENTER
            minHeight = dp(44)
            setPadding(dp(14), 0, dp(14), 0)
            background = bg(if (accent) C.AC else C.S2, 12, 1, if (accent) C.AC else C.LN)
            setOnClickListener { click() }
        }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- каркас ----------

    private fun buildShell() {
        val root = vbox()
        root.setBackgroundColor(C.BG)

        val head = hbox()
        head.setPadding(dp(12), dp(8), dp(12), dp(8))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.adjustViewBounds = true
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        head.addView(logo, lp(WRAP, dp(30)))
        head.addView(tv("Calendar", 15f, C.MU).apply { setPadding(dp(8), 0, 0, 0) }, lp(0, WRAP, 1f))
        head.addView(btn("Сегодня") {
            val t = D.today()
            tab = 0
            sel = t
            vy = D.y(t)
            vm = D.m(t)
            render()
        }, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        head.addView(btn("+", true) { editor(null, tab == 1) }, lp(dp(48), dp(48)))
        root.addView(head, lp(MATCH, WRAP))
        root.addView(View(this).apply { setBackgroundColor(C.LN) }, lp(MATCH, dp(1)))

        content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))

        root.addView(View(this).apply { setBackgroundColor(C.LN) }, lp(MATCH, dp(1)))
        val nav = hbox()
        tabCal = tv("Календарь", 13f, C.MU).apply {
            gravity = Gravity.CENTER
            setOnClickListener { tab = 0; render() }
        }
        tabTasks = tv("Задачи", 13f, C.MU).apply {
            gravity = Gravity.CENTER
            setOnClickListener { tab = 1; render() }
        }
        nav.addView(tabCal, lp(0, dp(54), 1f))
        nav.addView(tabTasks, lp(0, dp(54), 1f))
        root.addView(nav, lp(MATCH, WRAP))

        setContentView(root)
    }

    private fun render() {
        tabCal.setTextColor(if (tab == 0) C.AC else C.MU)
        tabTasks.setTextColor(if (tab == 1) C.AC else C.MU)
        content.removeAllViews()
        content.addView(if (tab == 0) calendarView() else tasksView())
    }

    // ---------- календарь ----------

    private fun shiftMonth(delta: Int) {
        vm += delta
        if (vm < 0) { vm = 11; vy-- } else if (vm > 11) { vm = 0; vy++ }
        val t = D.today()
        sel = if (D.y(t) == vy && D.m(t) == vm) t else D.key(vy, vm, 1)
        render()
    }

    private fun calendarView(): View {
        val sv = ScrollView(this)
        val col = vbox(14)
        sv.addView(col)

        val nav = hbox()
        nav.addView(btn("‹") { shiftMonth(-1) }, lp(dp(48), dp(48)))
        nav.addView(
            tv("${D.months[vm]} $vy", 20f, C.TX, true).apply { gravity = Gravity.CENTER },
            lp(0, WRAP, 1f)
        )
        nav.addView(btn("›") { shiftMonth(1) }, lp(dp(48), dp(48)))
        col.addView(nav, lp(MATCH, WRAP))

        val wk = hbox()
        for (n in listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")) {
            wk.addView(tv(n, 12f, C.MU).apply { gravity = Gravity.CENTER }, lp(0, WRAP, 1f))
        }
        col.addView(wk, lp(MATCH, WRAP).apply { topMargin = dp(10); bottomMargin = dp(4) })

        val byDate = Store.items.groupBy { it.date }
        val c = Calendar.getInstance()
        c.clear()
        c.set(vy, vm, 1)
        val first = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val dim = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        val rows = (first + dim + 6) / 7
        val today = D.today()

        for (r in 0 until rows) {
            val row = hbox()
            for (cc in 0 until 7) {
                val day = r * 7 + cc - first + 1
                if (day < 1 || day > dim) {
                    row.addView(View(this), lp(0, dp(52), 1f))
                    continue
                }
                val k = D.key(vy, vm, day)
                val list = byDate[k]
                val isSel = k == sel
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                if (isSel) cell.background = bg(C.AC, 12)
                else if (k == today) cell.background = bg(Color.TRANSPARENT, 12, 2, C.AC)
                cell.setOnClickListener { sel = k; render() }
                cell.addView(tv(day.toString(), 16f, if (isSel) C.DARK else C.TX, isSel))
                val dot = View(this)
                if (list != null) {
                    val active = list.any { !it.done }
                    dot.background = bg(if (isSel) C.DARK else if (active) C.AC else C.MU, 3)
                }
                cell.addView(dot, lp(dp(6), dp(6)).apply { topMargin = dp(3) })
                row.addView(cell, lp(0, dp(52), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
            col.addView(row, lp(MATCH, WRAP))
        }

        col.addView(tv(D.full(sel), 18f, C.TX, true), lp(WRAP, WRAP).apply { topMargin = dp(16); bottomMargin = dp(8) })
        val list = Store.items.filter { it.date == sel }
            .sortedWith(compareBy<Item>({ it.time }, { it.title.lowercase() }))
        if (list.isEmpty()) {
            col.addView(tv("На этот день ничего нет", 15f, C.MU))
        } else {
            for (x in list) col.addView(itemRow(x, false), lp(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }
        return sv
    }

    // ---------- задачи ----------

    private fun tasksView(): View {
        val sv = ScrollView(this)
        val col = vbox(14)
        sv.addView(col)
        val tasks = Store.items.filter { it.isTask }
        if (tasks.isEmpty()) {
            col.addView(
                tv("Задач нет. Нажмите «+», чтобы добавить.", 15f, C.MU).apply { gravity = Gravity.CENTER },
                lp(MATCH, WRAP).apply { topMargin = dp(48) }
            )
            return sv
        }
        val open = tasks.filter { !it.done }
            .sortedWith(compareBy<Item>({ it.date.isEmpty() }, { it.date }, { it.time }))
        val done = tasks.filter { it.done }.sortedByDescending { it.date }
        if (open.isNotEmpty()) {
            col.addView(tv("Активные · ${open.size}", 14f, C.MU), lp(WRAP, WRAP).apply { bottomMargin = dp(8) })
            for (x in open) col.addView(itemRow(x, true), lp(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }
        if (done.isNotEmpty()) {
            col.addView(tv("Выполненные · ${done.size}", 14f, C.MU), lp(WRAP, WRAP).apply { topMargin = dp(12); bottomMargin = dp(8) })
            for (x in done) col.addView(itemRow(x, true), lp(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }
        return sv
    }

    private fun toggle(x: Item) {
        x.done = !x.done
        Store.save(this)
        if (x.done) Notifier.cancel(this, x.id) else Notifier.schedule(this, x)
        render()
    }

    private fun meta(x: Item, showDate: Boolean): String {
        val p = ArrayList<String>()
        if (showDate) p.add(D.show(x.date))
        if (x.time.isNotEmpty()) p.add(if (x.endTime.isNotEmpty()) "${x.time}–${x.endTime}" else x.time)
        else if (!x.isTask) p.add("Весь день")
        if (x.remind >= 0) p.add("напоминание")
        return p.joinToString(" · ")
    }

    private fun itemRow(x: Item, showDate: Boolean): View {
        val row = hbox()
        row.background = bg(C.S1, 14)
        row.setPadding(dp(12), dp(8), dp(12), dp(8))
        row.setOnClickListener { editor(x, x.isTask) }

        if (x.isTask) {
            val box = FrameLayout(this)
            val inner = View(this)
            inner.background = bg(if (x.done) C.AC else Color.TRANSPARENT, 7, 2, if (x.done) C.AC else C.MU)
            box.addView(inner, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            box.setOnClickListener { toggle(x) }
            row.addView(box, lp(dp(44), dp(44)).apply { rightMargin = dp(4) })
        } else {
            val bar = View(this)
            bar.background = bg(C.AC, 2)
            row.addView(bar, lp(dp(4), dp(32)).apply { leftMargin = dp(2); rightMargin = dp(14) })
        }

        val tx = vbox()
        val t = tv(x.title, 16f, if (x.done) C.MU else C.TX, true)
        if (x.done) t.paintFlags = t.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        t.maxLines = 2
        t.ellipsize = TextUtils.TruncateAt.END
        tx.addView(t)
        val m = meta(x, showDate)
        if (m.isNotEmpty()) {
            val overdue = x.isTask && !x.done && x.date.isNotEmpty() && x.date < D.today()
            tx.addView(tv(m, 13f, if (overdue) C.DG else C.MU))
        }
        row.addView(tx, lp(0, WRAP, 1f))
        return row
    }

    // ---------- редактор ----------

    private fun editor(old: Item?, startTask: Boolean) {
        var isTask = old?.isTask ?: startTask
        var date = old?.date ?: (if (startTask) "" else sel)
        var time = old?.time ?: ""
        var end = old?.endTime ?: ""
        var remind = old?.remind ?: -1
        var refresh: () -> Unit = {}

        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val sv = ScrollView(this)
        val col = vbox(16)
        col.background = GradientDrawable().apply {
            setColor(C.S1)
            val r = dp(20).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        sv.addView(col)

        fun label(s: String) = col.addView(
            tv(s, 13f, C.MU), lp(WRAP, WRAP).apply { topMargin = dp(12); bottomMargin = dp(4) }
        )

        fun field(h: String, multi: Boolean) = EditText(this).apply {
            hint = h
            setHintTextColor(C.MU)
            setTextColor(C.TX)
            textSize = 16f
            background = bg(C.S2, 12, 1, C.LN)
            setPadding(dp(12), dp(11), dp(12), dp(11))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or
                (if (multi) InputType.TYPE_TEXT_FLAG_MULTI_LINE else 0)
            if (multi) {
                minLines = 3
                gravity = Gravity.TOP or Gravity.START
            }
        }

        // тип
        val bEv = tv("Событие", 15f, C.TX, true).apply { gravity = Gravity.CENTER; minHeight = dp(44) }
        val bTk = tv("Задача", 15f, C.TX, true).apply { gravity = Gravity.CENTER; minHeight = dp(44) }
        bEv.setOnClickListener { isTask = false; if (date.isEmpty()) date = sel; refresh() }
        bTk.setOnClickListener { isTask = true; refresh() }
        val seg = hbox()
        seg.addView(bEv, lp(0, WRAP, 1f).apply { rightMargin = dp(6) })
        seg.addView(bTk, lp(0, WRAP, 1f))
        col.addView(seg, lp(MATCH, WRAP))

        val title = field("Название", false)
        title.setText(old?.title ?: "")
        col.addView(title, lp(MATCH, WRAP).apply { topMargin = dp(12) })

        // дата
        label("Дата")
        val dateBtn = btn("") {
            val base = if (date.isEmpty()) D.today() else date
            DatePickerDialog(
                this, android.R.style.Theme_DeviceDefault_Dialog,
                { _, y, m, d -> date = D.key(y, m, d); refresh() },
                D.y(base), D.m(base), D.d(base)
            ).show()
        }
        val clrDate = btn("Сбросить") { date = ""; time = ""; end = ""; remind = -1; refresh() }
        val dateRow = hbox()
        dateRow.addView(dateBtn, lp(0, WRAP, 1f))
        dateRow.addView(clrDate, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        col.addView(dateRow, lp(MATCH, WRAP))

        // время
        fun pickTime(cur: String, def: String, set: (String) -> Unit) {
            val s = if (cur.isEmpty()) def else cur
            TimePickerDialog(
                this, android.R.style.Theme_DeviceDefault_Dialog,
                { _, h, m -> set(String.format(Locale.US, "%02d:%02d", h, m)); refresh() },
                s.substring(0, 2).toInt(), s.substring(3, 5).toInt(), true
            ).show()
        }
        label("Время")
        val timeBtn = btn("") {
            if (date.isEmpty()) date = D.today()
            pickTime(time, "09:00") { v -> time = v; if (end.isNotEmpty() && end < time) end = "" }
        }
        val endBtn = btn("") {
            pickTime(end, if (time.isEmpty()) "10:00" else time) { v -> end = v }
        }
        val clrTime = btn("Сброс") { time = ""; end = ""; refresh() }
        val timeRow = hbox()
        timeRow.addView(timeBtn, lp(0, WRAP, 1f))
        timeRow.addView(endBtn, lp(0, WRAP, 1f).apply { leftMargin = dp(8) })
        timeRow.addView(clrTime, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        col.addView(timeRow, lp(MATCH, WRAP))

        // напоминание
        label("Напоминание")
        val remBtn = btn("") {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Напоминание")
                .setItems(REM_LABELS) { _, w ->
                    remind = REM_MIN[w]
                    if (remind >= 0 && date.isEmpty()) date = D.today()
                    refresh()
                }.show()
        }
        col.addView(remBtn, lp(MATCH, WRAP))
        val remHint = tv("Без времени напоминание отсчитывается от 09:00", 12f, C.MU)
        col.addView(remHint, lp(WRAP, WRAP).apply { topMargin = dp(4) })

        // заметка
        label("Заметка")
        val note = field("Заметка", true)
        note.setText(old?.note ?: "")
        col.addView(note, lp(MATCH, WRAP))

        fun save() {
            val t = title.text.toString().trim()
            if (t.isEmpty()) { toast("Введите название"); return }
            if (!isTask && date.isEmpty()) date = sel
            if (isTask || time.isEmpty()) end = ""
            if (date.isEmpty()) { time = ""; remind = -1 }
            if (end.isNotEmpty() && end < time) { toast("Конец раньше начала"); return }
            val x = old ?: Item(Store.nextId(), isTask, t).also { Store.items.add(it) }
            x.isTask = isTask
            x.title = t
            x.note = note.text.toString().trim()
            x.date = date
            x.time = time
            x.endTime = end
            x.remind = remind
            if (!isTask) x.done = false
            Store.save(this)
            Notifier.cancel(this, x.id)
            Notifier.schedule(this, x)
            if (!isTask && tab == 0) { sel = date; vy = D.y(date); vm = D.m(date) }
            dlg.dismiss()
            render()
        }

        val act = hbox()
        if (old != null) {
            act.addView(btn("Удалить") {
                AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setMessage("Удалить «${old.title}»?")
                    .setPositiveButton("Удалить") { _, _ ->
                        Notifier.cancel(this, old.id)
                        Store.items.remove(old)
                        Store.save(this)
                        dlg.dismiss()
                        render()
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            }.also { it.setTextColor(C.DG) }, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        act.addView(btn("Сохранить", true) { save() }, lp(0, WRAP, 1f))
        col.addView(act, lp(MATCH, WRAP).apply { topMargin = dp(16) })

        refresh = {
            fun segStyle(b: TextView, on: Boolean) {
                b.setTextColor(if (on) C.DARK else C.MU)
                b.background = bg(if (on) C.AC else C.S2, 12, 1, if (on) C.AC else C.LN)
            }
            segStyle(bEv, !isTask)
            segStyle(bTk, isTask)
            dateBtn.text = D.show(date)
            clrDate.visibility = if (isTask && date.isNotEmpty()) View.VISIBLE else View.GONE
            timeBtn.text = if (time.isNotEmpty()) time else if (isTask) "Без времени" else "Весь день"
            endBtn.visibility = if (time.isNotEmpty() && !isTask) View.VISIBLE else View.GONE
            endBtn.text = if (end.isNotEmpty()) "до $end" else "Конец"
            clrTime.visibility = if (time.isNotEmpty()) View.VISIBLE else View.GONE
            remBtn.text = REM_LABELS[REM_MIN.indexOf(remind).coerceAtLeast(0)]
            remHint.visibility = if (remind >= 0 && time.isEmpty()) View.VISIBLE else View.GONE
        }
        refresh()

        dlg.setContentView(sv)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(MATCH, WRAP)
            setGravity(Gravity.BOTTOM)
            setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                    (if (old == null) WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE else 0)
            )
        }
        dlg.show()
        if (old == null) title.requestFocus()
    }
}
